#!/bin/bash
set -e

# ================== 基础配置 ==================
script_dir="/usr/local/Data-source"
script_file="$script_dir/Block_Bandwidth.sh"
output_dir="/var/log/mx-cIndicator"
hostname_file="/allconf/hostname.conf"  # 保留模板变量（未使用但兼容）

# ================== 1. 创建目录（静默执行） ==================
mkdir -p "$script_dir" "$output_dir" >/dev/null 2>&1

# ================== 2. 写入核心脚本（移除wework_code后） ==================
cat > "$script_file" << 'EOF'
#!/bin/bash
set -euo pipefail  # 严格的错误检查

# ================== 基础配置 ==================
output_dir="/var/log/mx-cIndicator"
output_file="$output_dir/ks_LH.prom"
tmp_file="$output_dir/ks_LH.tmp"  # 临时文件（原子替换用）
base_url="http://103.215.140.118:4433/provider/lfsy3289476"

# ================== 函数定义 ==================
# 1. 获取平台信息
get_planform() {
    local target_script="/usr/bin/issue.sh"
    local planform="third"
    [ ! -f "$target_script" ] || [ ! -r "$target_script" ] && { echo "$planform"; return; }
    grep -q "portal.chxyun.cn" "$target_script" 2>/dev/null && planform="mx"
    grep -q "www.smogfly.com" "$target_script" 2>/dev/null && planform="wc"
    echo "$planform"
}

# 2. 清理临时文件
cleanup() {
    rm -f "${output_dir}/temp_download.txt" "${output_dir}/extracted_data_*.txt"
}
trap cleanup EXIT

# ================== 前置检查 ==================
# 检查输出目录权限
if [ ! -w "$output_dir" ]; then
    echo "错误: 对目录 $output_dir 没有写入权限" >&2
    exit 1
fi

# 检查依赖工具
for cmd in curl bc jq awk grep sed; do
    if ! command -v "$cmd" &>/dev/null; then
        echo "错误: 缺少依赖工具 $cmd，请先安装" >&2
        exit 1
    fi
done

# ================== 核心逻辑 ==================
# 主动清理历史临时文件（避免长期积累）
find "$output_dir" -maxdepth 1 \( -name "extracted_data_*.txt" -o -name "temp_download.txt" \) -type f -mtime +1 -delete 2>/dev/null || true

# 1. 获取GUID
GUID=$(ps -ef | grep ksp2p | grep -oP '(?<=--guid=)[^ ]*' | head -n 1)
if [ -z "$GUID" ]; then
    echo "警告: 未获取到ksp2p进程的GUID，跳过指标生成" >&2
    # 写入默认指标（避免Prometheus采集不到数据）
    > "$tmp_file"
    echo "# HELP Ks_block_bandwidth Combined network metrics with threshold and blacklist values" >> "$tmp_file"
    echo "# TYPE Ks_block_bandwidth gauge" >> "$tmp_file"
    echo "Ks_block_bandwidth{interface=\"unknown\", planform=\"$(get_planform)\", Bandwidth=\"0\",blacklist_mbps=\"0\",threshold_mbps=\"0\"} 1" >> "$tmp_file"
    mv -f "$tmp_file" "$output_file"
    exit 0
fi

# 2. 构建日期和URL
PREVIOUS_DATE=$(date -d "yesterday" +"%Y%m%d")
CURRENT_DATE=$(date +"%Y%m%d")
full_url="${base_url}/${PREVIOUS_DATE}/limitNodeList/limitNodeList.txt" 

# 3. 下载数据（静默）
curl -s -o "${output_dir}/temp_download.txt" "$full_url"
if [ ! -s "${output_dir}/temp_download.txt" ]; then
    echo "警告: 下载数据为空，跳过指标生成" >&2
    > "$tmp_file"
    echo "# HELP Ks_block_bandwidth Combined network metrics with threshold and blacklist values" >> "$tmp_file"
    echo "# TYPE Ks_block_bandwidth gauge" >> "$tmp_file"
    echo "Ks_block_bandwidth{interface=\"unknown\", planform=\"$(get_planform)\", Bandwidth=\"0\",blacklist_mbps=\"0\",threshold_mbps=\"0\"} 1" >> "$tmp_file"
    mv -f "$tmp_file" "$output_file"
    exit 0
fi

# 4. 过滤匹配GUID的数据（直接提取，不保存中间文件）
if ! grep -q " $GUID " "${output_dir}/temp_download.txt"; then
    echo "警告: 未找到与GUID $GUID 匹配的数据，跳过指标生成" >&2
    > "$tmp_file"
    echo "# HELP Ks_block_bandwidth Combined network metrics with threshold and blacklist values" >> "$tmp_file"
    echo "# TYPE Ks_block_bandwidth gauge" >> "$tmp_file"
    echo "Ks_block_bandwidth{interface=\"unknown\", planform=\"$(get_planform)\", Bandwidth=\"0\",blacklist_mbps=\"0\",threshold_mbps=\"0\"} 1" >> "$tmp_file"
    mv -f "$tmp_file" "$output_file"
    exit 0
fi

# 5. 提取字段（直接处理，不保存中间文件）
grep " $GUID " "${output_dir}/temp_download.txt" | while read -r line; do
    guid=$(echo "$line" | awk '{print $2}')
    interface=$(echo "$line" | awk '{print $4}')
    singleline=$(echo "$line" | awk '{print $9}')
    threshold=$(echo "$line" | awk '{print $11}')
    blacklist=$(echo "$line" | awk '{print $12}')

# 6. 获取smallnode_control带宽数据（只执行一次，避免循环内重复执行）
bandwidth="0"
if command -v smallnode_control &>/dev/null; then
    json_output=$(smallnode_control -l --json 2>/dev/null)
    if [ $? -eq 0 ]; then
        bandwidth=$(echo "$json_output" | jq -r '.interface_list[0].Bandwidth // "0"' 2>/dev/null)
    fi
fi
# 确保bandwidth是数字
bandwidth=$(echo "$bandwidth" | grep -E '^[0-9.]+$' || echo "0")

# 7. 获取平台信息
planform=$(get_planform)

# 8. 生成Prometheus指标
> "$tmp_file"
echo "# HELP Ks_block_bandwidth Combined network metrics with threshold and blacklist values" >> "$tmp_file"
echo "# TYPE Ks_block_bandwidth gauge" >> "$tmp_file"

# 处理提取的数据行
tail -n +2 "${output_dir}/extracted_data_${CURRENT_DATE}.txt" | while read -r guid interface singleline threshold blacklist; do
    # 转换单位（Gbps→Mbps）并清理格式
    threshold_mbps=$(echo "$threshold * 1000" | bc -l | sed -E 's/\.0+$//; s/\..*//; s/^$/0/')
    blacklist_mbps=$(echo "$blacklist * 1000" | bc -l | sed -E 's/\.0+$//; s/\..*//; s/^$/0/')
    bandwidth_num=$(echo "$bandwidth" | sed -E 's/\.0+$//; s/\..*//; s/^$/0/')

    # 计算指标值（带宽>临界值则0，否则1）
    if [ "$bandwidth_num" -gt "$threshold_mbps" ] 2>/dev/null; then
        metric_value="0"
    else
        metric_value="1"
    fi

    # 标准化接口名称（避免空值）
    interface=${interface:-"unknown"}

    # 写入指标（符合Prom规范，标签值转义）
    echo "Ks_block_bandwidth{interface=\"$interface\", planform=\"$planform\", Bandwidth=\"$bandwidth\",blacklist_mbps=\"$blacklist_mbps\",threshold_mbps=\"$threshold_mbps\"} $metric_value" >> "$tmp_file"
done

# 原子替换正式文件（核心优化：避免半写）
mv -f "$tmp_file" "$output_file"

# ================== 完成 ==================
echo "成功生成指标文件: $output_file"
exit 0
EOF

# 赋予执行权限
chmod +x "$script_file"

# ================== 3. 创建systemd服务文件（标准化） ==================
cat > /etc/systemd/system/Block_Bandwidth.service << 'EOF'
[Unit]
Description=Run Block_Bandwidth.sh script to check for ks Block
After=network.target

[Service]
Type=oneshot
ExecStart=/usr/local/Data-source/Block_Bandwidth.sh
TimeoutSec=30
ProtectSystem=off
# 静默执行（只输出错误）
StandardOutput=null
StandardError=journal+console
EOF

# ================== 4. 创建systemd定时器文件（标准化） ==================
cat > /etc/systemd/system/Block_Bandwidth.timer << 'EOF'
[Unit]
Description=Run Block_Bandwidth.sh daily at 12:00 PM

[Timer]
OnCalendar=*-*-* 12:00:00
Persistent=true
AccuracySec=1

[Install]
WantedBy=timers.target
EOF

# ================== 5. 启动配置（静默执行，和你的模板对齐） ==================
chmod 644 /etc/systemd/system/Block_Bandwidth.service
chmod 644 /etc/systemd/system/Block_Bandwidth.timer

systemctl daemon-reload >/dev/null 2>&1
systemctl disable --now Block_Bandwidth.service >/dev/null 2>&1 || true
systemctl disable --now Block_Bandwidth.timer >/dev/null 2>&1 || true
systemctl enable --now Block_Bandwidth.timer >/dev/null 2>&1

# 验证定时任务状态
echo "定时任务配置完成，每天12:00执行Block_Bandwidth.sh"
echo "当前定时器状态："
systemctl list-timers | grep Block_Bandwidth || echo "未找到定时器（可能刚创建）"